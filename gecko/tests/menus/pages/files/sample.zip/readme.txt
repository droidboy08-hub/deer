Vitre menus test data
